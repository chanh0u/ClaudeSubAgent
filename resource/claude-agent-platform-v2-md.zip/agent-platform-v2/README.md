# Claude Agent 관리 플랫폼 v2 — Claude Code 연동 가이드

---

## 플랫폼 특징

| 기능 | 설명 |
|------|------|
| 대화 기반 수집 | LLM과 자연어 대화로 요구사항 추출 |
| LLM 선택 | 내부 LLM(폐쇄망) 또는 외부 LLM(Claude API) 환경변수 전환 |
| 기술 스택 선택 | Web/DB/Backend + 언어(C,C++,Java,Python,JS) + 도메인 |
| 사용자 승인 게이트 | 요약 검토 후 OK 시에만 코드 생성 시작 |
| 다언어 지원 | Python/Java/JS/C/C++ 모두 대응 |
| 도메인 특화 | 금융·공공·B2B·B2C별 보안·구조 자동 적용 |

---

## 빠른 시작

```bash
# 1. Claude Code 설치
npm install -g @anthropic-ai/claude-code

# 2. LLM 환경변수 설정
export LLM_MODE=external
export ANTHROPIC_API_KEY=sk-ant-...

# 3. 프로젝트 열기
cd agent-platform-v2
claude

# 4. 플랫폼 시작
/start
```

---

## 4단계 실행 플로우

```
┌─────────────────────────────────────────────────────────────┐
│ Phase A — 대화 수집                                          │
│  사용자 ↔ LLM 대화 → 요구사항 자연어 입력                    │
│  [서비스 시작하기] 버튼 클릭 → docs/conversation-summary.md  │
├─────────────────────────────────────────────────────────────┤
│ Phase B — 기술 스택 선택                                     │
│  Web / DB / Backend / 언어 / 프로젝트 방향 / 도메인 / 품질   │
│  미선택 항목은 AI 자동 추론 → docs/stack-selection.md        │
├─────────────────────────────────────────────────────────────┤
│ Phase C — 최종 검토 승인                                     │
│  요약본 제시 → [OK] 또는 [수정 요청]                         │
│  OK → docs/final-approval.md 생성                           │
│  수정 → 해당 Phase 재순환                                    │
├─────────────────────────────────────────────────────────────┤
│ Phase D — POC 코드 생성 (사용자 OK 이후에만 실행)            │
│  orchestrator → Agent 팀 → ZIP/Git → 로컬 POC 구동           │
└─────────────────────────────────────────────────────────────┘
```

---

## 디렉터리 구조

```
agent-platform-v2/
├── CLAUDE.md                           ← 프로젝트 컨텍스트
├── README.md
│
├── .claude/
│   ├── agents/
│   │   ├── conversation-collector.md   ← Phase A (Sonnet)
│   │   ├── stack-selector.md           ← Phase B (Sonnet)
│   │   ├── review-presenter.md         ← Phase C (Sonnet)
│   │   ├── orchestrator.md             ← Phase D 총괄 (Opus)
│   │   ├── spec-analyst.md             ← 요구사항 명세 (Sonnet)
│   │   ├── backend-architect.md        ← API·서비스 (Sonnet)
│   │   ├── frontend-developer.md       ← UI·상태관리 (Sonnet)
│   │   ├── database-architect.md       ← DB·마이그레이션 (Sonnet)
│   │   ├── security-auditor.md         ← OWASP 검토 (Opus)
│   │   ├── test-automator.md           ← 테스트 생성 (Haiku)
│   │   ├── devops-engineer.md          ← Docker·CI/CD (Sonnet)
│   │   └── code-reviewer.md            ← 품질 게이트 (Opus)
│   │
│   ├── commands/
│   │   ├── start.md                    ← /start  (메인 진입점)
│   │   └── generate.md                 ← /generate (고급 직접 실행)
│   │
│   └── skills/
│       ├── fastapi-skill.md
│       ├── react-vite-skill.md
│       └── spring-boot-skill.md
│
└── docs/
    └── architecture.md
```

---

## 에이전트 팀 구성

| 에이전트 | Phase | 모델 | 역할 |
|---|---|---|---|
| conversation-collector | A | Sonnet | LLM 대화 수집 |
| stack-selector | B | Sonnet | 기술 스택 선택 |
| review-presenter | C | Sonnet | 최종 요약 검토 |
| orchestrator | D | **Opus** | 팀 편성·조율 |
| spec-analyst | D | Sonnet | 요구사항 명세 |
| backend-architect | D | Sonnet | 백엔드 구현 |
| frontend-developer | D | Sonnet | 프론트엔드 구현 |
| database-architect | D | Sonnet | DB 스키마 |
| security-auditor | D | **Opus** | 보안 검토 |
| test-automator | D | **Haiku** | 테스트 생성 |
| devops-engineer | D | Sonnet | Docker·CI/CD |
| code-reviewer | D | **Opus** | 품질 게이트 |

---

## 지원 기술 스택

### 프로그래밍 언어
`Python` `Java` `JavaScript / TypeScript` `C` `C++` `Go`

### Backend 프레임워크
`FastAPI` `Spring Boot` `Express` `NestJS` `Django`

### Frontend 프레임워크
`React + Vite` `Vue 3` `Next.js` `Angular`

### Database
`PostgreSQL` `MySQL` `MongoDB` `Redis`

### 도메인
`금융·보험` `유통·물류` `공공·의료` `B2B` `B2C` `제조·IT`

---

## 결과물 구조 (Phase D 완료 후)

```
/workspace/{project_id}/
├── src/               # 소스코드
├── tests/             # 테스트 코드
├── migrations/        # DB 마이그레이션
├── .github/workflows/ # CI/CD
├── docs/
│   ├── conversation-summary.md  # 대화 요약
│   ├── stack-selection.md       # 스택 선택 결과
│   ├── final-approval.md        # 사용자 승인 기록
│   ├── requirements.md
│   ├── api-spec.md
│   ├── security-report.md
│   └── code-review-report.md
├── Dockerfile
├── docker-compose.yml
├── .env.example
└── README.md          ← docker-compose up -d 실행 방법
```

---

## 보안 원칙

> ⚠️ `.claude/` 디렉터리는 ZIP에 절대 포함하지 않습니다.
> Phase D는 `docs/final-approval.md` 생성 이후에만 시작됩니다.
> API 키는 서버 사이드 환경변수로만 관리합니다.

---

*Claude Agent 관리 플랫폼 v2 | Sub-Agents + Agent Teams + Agent SDK*
