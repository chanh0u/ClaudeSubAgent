# React + Vite 프로젝트 스킬

frontend-developer 에이전트가 React 선택 시 참조.

## 핵심 패키지 (package.json)
```json
{
  "dependencies": {
    "react": "^18.3.0", "react-dom": "^18.3.0",
    "react-router-dom": "^6.26.0",
    "@tanstack/react-query": "^5.56.0",
    "axios": "^1.7.0", "zustand": "^4.5.0"
  },
  "devDependencies": {
    "@vitejs/plugin-react": "^4.3.0",
    "typescript": "^5.5.0", "vite": "^5.4.0"
  }
}
```

## 프로젝트 구조
```
src/
├── App.tsx           # 라우팅 + QueryClientProvider
├── api/client.ts     # axios 인스턴스 + 인터셉터
├── components/common/# Layout, Button, Input, Modal
├── pages/            # 페이지 컴포넌트
├── hooks/            # 커스텀 훅
├── store/authStore.ts# Zustand 인증 스토어
└── types/            # TypeScript 인터페이스
```

## API 클라이언트 패턴
```typescript
const client = axios.create({ baseURL: import.meta.env.VITE_API_BASE_URL });
client.interceptors.request.use(cfg => {
  const t = localStorage.getItem('accessToken');
  if (t) cfg.headers.Authorization = `Bearer ${t}`;
  return cfg;
});
```
