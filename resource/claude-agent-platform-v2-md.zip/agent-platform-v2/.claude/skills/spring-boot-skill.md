# Spring Boot 프로젝트 스킬

backend-architect 에이전트가 Java/Spring Boot 선택 시 참조.

## 핵심 의존성 (pom.xml)
```xml
<parent>
  <artifactId>spring-boot-starter-parent</artifactId>
  <version>3.3.0</version>
</parent>
<!-- web, data-jpa, security, validation, actuator, postgresql, flyway, lombok, springdoc -->
```

## 표준 응답
```java
@Getter @Builder
public class ApiResponse<T> {
    private boolean success;
    private T data;
    private String message;
    public static <T> ApiResponse<T> success(T data) { ... }
    public static <T> ApiResponse<T> error(String msg) { ... }
}
```

## application.yml 핵심 설정
```yaml
spring:
  datasource.url: ${DATABASE_URL}
  jpa.hibernate.ddl-auto: validate
  flyway.enabled: true
jwt:
  secret: ${JWT_SECRET}
  expiration: 1800000
```
