# FastAPI 프로젝트 스킬

backend-architect 에이전트가 Python/FastAPI 선택 시 참조하는 보일러플레이트 패턴.

## 핵심 패키지 (requirements.txt)
```
fastapi==0.115.0
uvicorn[standard]==0.30.0
sqlalchemy[asyncio]==2.0.0
asyncpg==0.29.0
alembic==1.13.0
pydantic-settings==2.5.0
python-jose[cryptography]==3.3.0
passlib[bcrypt]==1.7.4
httpx==0.27.0
pytest==8.3.0
pytest-asyncio==0.24.0
pytest-cov==5.0.0
```

## 프로젝트 구조
```
src/
├── main.py           # FastAPI 앱 + CORS + 라우터
├── core/
│   ├── config.py     # pydantic-settings 환경변수
│   ├── database.py   # AsyncSession + get_db
│   └── security.py   # JWT 생성/검증, bcrypt
├── api/v1/           # 엔드포인트 핸들러
├── service/          # 비즈니스 로직
└── domain/           # SQLAlchemy 모델 + Pydantic 스키마
```

## 표준 응답
```python
class ApiResponse(BaseModel, Generic[T]):
    success: bool = True
    data: Optional[T] = None
    message: str = ""
    error: Optional[str] = None
```
