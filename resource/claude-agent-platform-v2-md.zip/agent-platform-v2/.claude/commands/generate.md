# /generate — Phase D 직접 실행 (고급 사용자)

대화 수집 없이 요구사항을 직접 입력하여 코드를 생성합니다.
`docs/final-approval.md`가 없으면 자동으로 생성하고 Phase D를 시작합니다.

## 사용법
```
/generate {요구사항}

예시:
/generate FastAPI + React 사용자 관리 시스템. 
스택: Python/FastAPI + React + PostgreSQL. 방향: 신규 구축. 도메인: B2B.
기능: 회원가입, 로그인, 프로필, 관리자 대시보드.
```

## 옵션 파라미터
| 키워드 | 예시 | 설명 |
|--------|------|------|
| 스택 | `스택: Spring Boot + Vue` | 기술 스택 지정 |
| 방향 | `방향: 신규 구축` | 프로젝트 유형 |
| 도메인 | `도메인: 금융` | 업무 영역 |
| 언어 | `언어: Java` | 프로그래밍 언어 |
| 품질 | `품질: enterprise` | prototype/standard/enterprise |
