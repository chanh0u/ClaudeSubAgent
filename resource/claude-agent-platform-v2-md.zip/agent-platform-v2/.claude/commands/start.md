# /start — 플랫폼 메인 진입점

## 사용법
```
/start
```

## 실행 흐름

```
Phase A: conversation-collector 에이전트 시작
         → 사용자와 대화 (내부/외부 LLM)
         → "서비스 시작하기" 버튼 클릭 시 요약 생성

Phase B: stack-selector 에이전트 시작
         → 기술 스택 / 프로젝트 방향 / 도메인 / 품질 선택

Phase C: review-presenter 에이전트 시작
         → 최종 요약본 제시
         → OK → Phase D 시작
         → 수정 → 해당 Phase 재순환

Phase D: orchestrator → Agent 팀 → POC 코드 생성
```

## LLM 환경변수 사전 설정 필요

```bash
# 내부 LLM
export LLM_MODE=internal
export INTERNAL_LLM_URL=http://localhost:11434

# 외부 LLM (Claude)
export LLM_MODE=external
export ANTHROPIC_API_KEY=sk-ant-...
```
