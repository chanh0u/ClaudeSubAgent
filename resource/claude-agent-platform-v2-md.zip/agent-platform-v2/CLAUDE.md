# Claude Agent 관리 플랫폼 v2 — 프로젝트 컨텍스트

## 플랫폼 개요

사용자가 **LLM과 대화**하여 요구사항을 자연어로 말하면, 플랫폼이 이를 구조화하고
기술 스택·프로젝트 방향·도메인 영역을 선택한 뒤 최종 요약을 검토 받은 후
**서비스 시작 OK** 신호를 받았을 때 Agent 팀이 POC 코드를 자동 생성하는 플랫폼.

## 4단계 실행 Phase

```
Phase A — 대화 수집:  사용자 ↔ LLM 대화 → 요구사항 추출
Phase B — 스택 선택:  기술 스택 / 프로젝트 방향 / 도메인 영역 선택
Phase C — 검토 승인:  요약본 제시 → 사용자 OK / 수정 요청
Phase D — 코드 생성:  OK 이후 Agent 팀 실행 → ZIP/Git 제공
```

## LLM 연동 방식

### 내부 LLM (폐쇄망)
```bash
# .env 설정
LLM_MODE=internal
INTERNAL_LLM_URL=http://internal-ollama:11434
INTERNAL_LLM_MODEL=llama3.1:70b
```

### 외부 LLM (Claude API)
```bash
LLM_MODE=external
ANTHROPIC_API_KEY=sk-ant-...
CONVERSATION_MODEL=claude-sonnet-4-6   # 대화용 (비용 절감)
AGENT_MODEL=claude-opus-4-5            # orchestrator (고품질)
```

## 핵심 보안 원칙 (반드시 준수)

1. `.claude/agents/` 디렉터리는 ZIP 패키징에서 **절대 제외**
2. 모든 코드 생성은 `/workspace/{project_id}/` 하위에서만 수행
3. Phase D는 사용자 OK 신호 수신 후에만 시작 (자동 실행 금지)
4. API 키·시크릿은 서버 사이드 환경 변수로만 관리

## 파일 소유권

| 경로 | 담당 에이전트 |
|------|------------|
| `docs/` | spec-analyst |
| `src/api/`, `src/service/`, `src/domain/` | backend-architect |
| `src/components/`, `src/pages/`, `src/hooks/` | frontend-developer |
| `src/db/`, `migrations/` | database-architect |
| `tests/` | test-automator |
| `Dockerfile`, `docker-compose.yml`, `.github/` | devops-engineer |

## 기본 기술 스택 (미선택 시 적용)

- Backend: FastAPI (Python 3.11+)
- Frontend: React 18 + Vite + TypeScript
- Database: PostgreSQL 15
- Container: Docker + docker-compose
